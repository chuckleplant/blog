#pragma once

// Engine
#include "CoreMinimal.h"
#include "Animation/AnimNodeBase.h"
#include "AnimNodes/AnimNode_TwoWayBlend.h"
#include "AnimNodes/AnimNode_ModifyCurve.h"

#include "AnimNode_NestedNodes.generated.h"

USTRUCT(BlueprintInternalUseOnly)
struct ANIMCODE_API FAnimNode_NestedNodes final : public FAnimNode_Base
{
    GENERATED_BODY()

public:
    // FAnimNode_Base interface
    void Initialize_AnyThread(const FAnimationInitializeContext& Context) final;
    void Update_AnyThread(const FAnimationUpdateContext& Context) final;
    void CacheBones_AnyThread(const FAnimationCacheBonesContext& Context) final;
    void Evaluate_AnyThread(FPoseContext& Output) final;
    void GatherDebugData(FNodeDebugData& DebugData) final;
    // FAnimNode_Base interface end

private:
    void UpdateBlendWeight(const FAnimationUpdateContext& Context);

public:
    // Exposed pose pin
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = Links)
    FPoseLink PoseA;

    // Exposed pose pin
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = Links)
    FPoseLink PoseB;

    // Node property that will be available in the details panel
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = Blend)
    UCurveFloat* BlendWeightCurve = nullptr;
    
    // Node property that will be available in the details panel
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = ModifyCurve)
    FName CurveName;

private:
    // Blend node
    FAnimNode_TwoWayBlend   mBlend;
    FAnimNode_ModifyCurve   mModifyCurve;

    // Blend weight control variables
    float                   mBlendWeight = 0.f;
    float                   mCurveTime = 0.f;
};
