#include "Modules/ModuleManager.h"

IMPLEMENT_MODULE(FDefaultModuleImpl, AnimCode);