// Game
#include "AnimNodes/AnimNode_NestedNodes.h"



void FAnimNode_NestedNodes::Initialize_AnyThread(const FAnimationInitializeContext& Context)
{
    DECLARE_SCOPE_HIERARCHICAL_COUNTER_ANIMNODE(Initialize_AnyThread)
    FAnimNode_Base::Initialize_AnyThread(Context);

    // Connect pins to our two way blend, set to float type
    mBlend.A = PoseA;
    mBlend.B = PoseB;
    mBlend.AlphaInputType = EAnimAlphaInputType::Float;
    mBlend.Alpha = 0.f;
    mBlend.Initialize_AnyThread(Context);

    mModifyCurve.SourcePose.SetLinkNode(&mBlend);
    if (BlendWeightCurve == nullptr || CurveName == NAME_None)
    {
        return;
    }
    mModifyCurve.CurveMap.FindOrAdd(CurveName) = 0.f;
}

void FAnimNode_NestedNodes::Update_AnyThread(const FAnimationUpdateContext& Context)
{
    DECLARE_SCOPE_HIERARCHICAL_COUNTER_ANIMNODE(Update_AnyThread);

    // Update the blend node alpha based on our input curve
    UpdateBlendWeight(Context);

    // Here we just update our blend node, and it will internally evaluate our source Poses A and B
    mModifyCurve.Update_AnyThread(Context);
}

void FAnimNode_NestedNodes::CacheBones_AnyThread(const FAnimationCacheBonesContext& Context)
{
    DECLARE_SCOPE_HIERARCHICAL_COUNTER_ANIMNODE(CacheBones_AnyThread);
    mModifyCurve.CacheBones_AnyThread(Context);
}

void FAnimNode_NestedNodes::Evaluate_AnyThread(FPoseContext& Output)
{
    DECLARE_SCOPE_HIERARCHICAL_COUNTER_ANIMNODE(Evaluate_AnyThread);

    // This will internally call the evaluation of our source poses
    mModifyCurve.Evaluate_AnyThread(Output);
}

void FAnimNode_NestedNodes::GatherDebugData(FNodeDebugData& DebugData)
{
    DECLARE_SCOPE_HIERARCHICAL_COUNTER_ANIMNODE(GatherDebugData)
    FString DebugLine = DebugData.GetNodeName(this);
    DebugLine += FString::Printf(TEXT("(CurveTime: %.1f%)"), mCurveTime);
    DebugData.AddDebugItem(DebugLine);
    mBlend.GatherDebugData(DebugData);
}

void FAnimNode_NestedNodes::UpdateBlendWeight(const FAnimationUpdateContext& Context)
{
    if (BlendWeightCurve == nullptr || BlendWeightCurve->FloatCurve.Keys.Num() == 0)
    {
        return;
    }

    const float DeltaTime       = Context.GetDeltaTime();
    mCurveTime                  += DeltaTime;
    const float CurveDuration   = BlendWeightCurve->FloatCurve.Keys.Last().Time;
    mCurveTime                  = FMath::Fmod(mCurveTime, CurveDuration);
    mBlend.Alpha                = BlendWeightCurve->GetFloatValue(mCurveTime);

    if(CurveName == NAME_None)
    {
        return;
    }
    // Update modify curve value
    mModifyCurve.CurveMap.FindOrAdd(CurveName) = mBlend.Alpha;
}