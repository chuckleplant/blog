using UnrealBuildTool; 

public class AnimCode: ModuleRules 
{ 
	public AnimCode(ReadOnlyTargetRules Target) : base(Target) 
	{
		PrivateDependencyModuleNames.AddRange(new string[]
		{
			"AnimGraphRuntime",
            
            "Core",
			"CoreUObject",
			"Engine"
		}); 
	}
}