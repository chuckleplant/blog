Find the license here:
https://chuckleplant.github.io/about/

When you add these modules to your project make sure to specify them as:

{
	"Name": "AnimCode",
	"Type": "Runtime"
},
{
	"Name": "AnimCodeEditor",
	"Type": "UncookedOnly"
}