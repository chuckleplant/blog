#include "AnimNodes/AnimGraphNode_NestedNodes.h"

#define LOCTEXT_NAMESPACE "AnimGraphNode_NestedNodes"

FLinearColor UAnimGraphNode_NestedNodes::GetNodeTitleColor() const
{
    return FColorList::CoolCopper;
}

FText UAnimGraphNode_NestedNodes::GetTooltipText() const
{
    return LOCTEXT("NodeTooltip", "Example of nested node, use a curve asset to drive the animation blend.");
}

FText UAnimGraphNode_NestedNodes::GetNodeTitle(ENodeTitleType::Type TitleType) const
{
    return LOCTEXT("NodeTitle", "Blend by Curve");
}

FText UAnimGraphNode_NestedNodes::GetMenuCategory() const
{
    return LOCTEXT("Category", "Animation|Blends");
}

#undef LOCTEXT_NAMESPACE