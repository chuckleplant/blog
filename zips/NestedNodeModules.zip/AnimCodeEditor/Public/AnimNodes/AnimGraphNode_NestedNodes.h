#pragma once

// Game
#include "AnimNodes/AnimNode_NestedNodes.h"

// Engine
#include "CoreMinimal.h"
#include "AnimGraphNode_Base.h"

#include "AnimGraphNode_NestedNodes.generated.h"

UCLASS(MinimalAPI)
class UAnimGraphNode_NestedNodes final : public UAnimGraphNode_Base
{
    GENERATED_BODY()

public:
    UPROPERTY(EditAnywhere)
    FAnimNode_NestedNodes Node;

public:
    // UAnimGraphNode_Base interface
    FLinearColor    GetNodeTitleColor() const final;
    FText           GetTooltipText() const final;
    FText           GetNodeTitle(ENodeTitleType::Type TitleType) const final;
    FText           GetMenuCategory() const final;
    // UAnimGraphNode_Base interface end
};