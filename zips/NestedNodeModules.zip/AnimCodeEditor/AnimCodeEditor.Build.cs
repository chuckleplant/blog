using UnrealBuildTool; 

public class AnimCodeEditor: ModuleRules 
{ 
	public AnimCodeEditor(ReadOnlyTargetRules Target) : base(Target) 
	{
        OverridePackageType = PackageOverrideType.GameUncookedOnly;

        PrivateDependencyModuleNames.AddRange(new string[] 
		{
            "AnimGraph",
            "AnimGraphRuntime",
            "BlueprintGraph",
            "Core", 
			"CoreUObject",
			"Engine",

			// Game
			"AnimCode"
		}); 
	}
}