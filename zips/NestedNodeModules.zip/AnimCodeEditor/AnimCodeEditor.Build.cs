using UnrealBuildTool; 

public class AnimCodeEditor: ModuleRules 
{ 
	public AnimCodeEditor(ReadOnlyTargetRules Target) : base(Target) 
	{
		PrivateDependencyModuleNames.AddRange(new string[] 
		{
            "AnimGraph",
            "AnimGraphRuntime",
            "BlueprintGraph",
            "Core", 
			"CoreUObject",
			"Engine",

			// Game
			"AnimCode"
		}); 
	}
}